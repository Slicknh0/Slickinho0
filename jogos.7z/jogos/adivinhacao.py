print("*******************************")
print("Bem-vindo ao jogo de advinhação")
print("*******************************")

numero_secreto = 50
tentativas = 5
rodada = 1

for rodada in range(1 + tentativas +1):
    print("Tentativas {} de {}" .format(rodada,tentativas))
    chute = int(input("Digite um numero entre 1 a 100: "))
    print("Voce digitou: ", chute)

    if (chute < 1 or chute > 100):
       print("Voce deve digitar um numero entre 1 a 100!")
       continue

    acertou = (numero_secreto == chute)
    maior   = (chute > numero_secreto)
    menor   = (chute < numero_secreto)

    if (numero_secreto == chute):
        print("Voce acertou")
        break

    else:
        if (maior):
            print("Voce errou! o numero foi maior que o esperado")
        elif (menor):
            print("Voce errou! o numero foi menor que o esperado")


print("fim de jogo!")